package com.playpiece.PlayPiece;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayPieceApplicationTests {

	@Test
	void contextLoads() {
	}

}
