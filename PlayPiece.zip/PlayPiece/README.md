# PlayPiece
Projeto desenvolvido durante o 4º semestre do curso de Tecnologia em Análise e Desenvolvimento de Sistemas na matéria de Projeto Integrador.

-Para rodar o projeto, é necessario ter o MySQL Workbench instalado na maquina.
-Importar o banco de dados atraves do caminho: 
    ..\PlayPieceMaster\PlayPiece\PlayPieceDB Creation\criacaoDB.sql

-Verificar informações usadas no arquivo application.properties
    Verificar em qual porta do banco de dados o projeto está rodando 
    Verificar o usuario 
    Verificar a senha

Caminho do arquivo application.properties:
    ..\PlayPiece\PlayPieceAPI\src\main\resources\application.properties



** Acessos padrão **

Administrador Sistema

lfujimura.pp1@playpiece.com
123123123


Estoquista

vmendes.pp2@playpiece.com
123123123


